# LLM-GM Online Fantasy RPG Work Pack (Web + Mobile) — Replit Upload Pack

This work pack consolidates everything from the conversation thread into a single uploadable bundle:
- Product north star and requirements (MVP → V1)
- Non-functional requirements
- Architecture decisions and module breakdown
- Deterministic rules layer (original ruleset: **Mythweave Lite**)
- LLM GM orchestration contract (JSON) + Zod schemas
- Tool result schemas (Zod) + canonical tool result message format
- GM system prompt (JSON-only, tool-using, arc-aware, injection-resistant)
- Server-side validation + `proposeUpdates` tool skeleton (atomic validation/commit)
- Replit Agent milestone prompt pack (copy/paste)

## How to use in Replit
1. **Upload this entire folder** into your Replit project (or import the zip).
2. In Replit Agent, paste the prompts from:
   - `replit/REPLIT_AGENT_PROMPTS.md` (in order)
   - and always prepend the constraints block:
     - `replit/REPLIT_AGENT_CONSTRAINTS_BLOCK.md`
3. As the repo is created, copy the TypeScript/Markdown files into their target paths:
   - `packages/shared/src/...`
   - `backend/src/...`
4. Wire your orchestrator to:
   - validate GM JSON using `GMResponseSchema`
   - execute tool calls
   - feed tool results back using `ToolResultsMessageSchema`
   - validate + commit updates via `validateProposedUpdates` + `proposeUpdatesTool`

---

## 0) North Star (Product Goal)
Build a web + mobile-compatible online fantasy RPG where:
- An LLM acts as the Game Master (GM), using tools (server functions) and strict JSON outputs.
- Players join solo or as parties with friends (real-time + async).
- Players have true agency (freeform actions), with enforced rules (dice, stats, constraints).
- The world is persistent: characters, inventories, relationships, locations, quests, consequences carry forward.
- The story forms meaningful narrative arcs with natural chapter endpoints.
- The interface features generative ambience (background art prompts, location soundscape prompts, optional NPC voice hints) that evolves with the story.
- **Art direction safety:** do NOT reference living artists. Implement a configurable, original art direction:
  - “high-fantasy painterly / cinematic luminous” with sliders (palette, contrast, line sharpness, detail level)
  - optional original “style packs” (generic descriptors only)

### North Star Metric
**% of sessions that reach a chapter endpoint with:**
- (a) no continuity errors (canonical state vs narration contradictions), and
- (b) player satisfaction ≥ 4/5.

---

## 1) Product Requirements (MVP → V1)

### 1.1 MVP (first playable)
Core loop:
1) Create character (name, class, race, background, appearance)
2) Join/create a party + campaign
3) GM introduces scene → players act (freeform) → rules resolved → world updates → scene continues
4) At arc checkpoints: rewards, level progression, summary, next hook

Must-have features:
- Accounts + authentication
- Campaign lobby + party management (invite link)
- Real-time chat + turn handling (websocket)
- Character sheets: stats, HP, XP/level, skills, spells/abilities, inventory
- Dice engine (d20 + modifiers + advantage/disadvantage)
- GM that:
  - responds narratively
  - calls tools for rules + state updates
  - keeps continuity using canonical state + summaries + retrieval memory
- Persistence: save/load campaigns and characters

### 1.2 V1 (after MVP)
- Multi-arc campaigns with chapter summaries + “Previously on…”
- Relationship system (party bonds, NPC affinity, factions)
- Crafting/loot tables + economy
- Map/locations browsing and “travel”
- Optional voice TTS for GM + NPCs
- Ambient soundscapes by location + event type
- Image generation for scene backgrounds + key NPC reveals
- Content safety controls + reporting + parental settings

---

## 2) Non-Functional Requirements
- **Mobile compatible:** responsive web app + PWA; optionally wrap with Capacitor later.
- **Latency:** target <2s for most GM responses; use streaming tokens.
- **Cost controls:** caching, summarization, “fast mode vs cinematic mode”.
- **Reliability:** event-sourced game log so state can be rebuilt.
- **Safety:** moderation layer, jailbreak resistance, user controls, safe defaults.

---

## 3) Architecture Overview (Recommended for Replit)
**Chosen stack (simple + scalable):**
- Frontend: Next.js + Tailwind + PWA
- Backend: Node.js + Fastify
- Realtime: WebSockets (rooms per party_id), token streaming
- Persistence: Postgres (Replit SQL / Neon-backed in prod)
- LLM provider: behind `LLMClient` interface
- Media generation: behind `ImageGenClient` and `AudioClient` interfaces (optional/off by default)
- Memory: summaries now; pgvector optional later (Tier C)

**Key architectural decision:** one externally-exposed port.
- Run Fastify as the main server.
- Mount Next.js SSR through Fastify.
- Serve REST + WebSockets on the same port.

High-level modules:
- `game-engine/` (rules, dice, validations, state transitions)
- `gm-orchestrator/` (prompting, tool calls, narrative control)
- `memory/` (summaries, embeddings, retrieval)
- `api/` (auth, campaigns, characters, logs)
- `realtime/` (socket events, presence, turn-taking)
- `media/` (image/audio prompts, caching, delivery)
- `frontend/` (UI)

---

## 4) Event sourcing + snapshot (critical)
- `game_events` is append-only.
- `world_state` is a derived snapshot.
- Everything (actions, dice rolls, outcomes, loot, relationship changes, chapter endpoints) is logged as events.
- Snapshot can be rebuilt from the event log.

---

## 5) GM Orchestrator Contract (Strict JSON)
The GM responds with **one JSON object** (validated by Zod):
- Narrative markdown (streamed optionally)
- Clarifications (if player intent ambiguous)
- Tool calls (server executes)
- Proposed updates (validated and committed by server)
- Media prompts (text prompts only; generation separate)

See:
- `packages/shared/src/gm/schemas.ts` (GMResponseSchema)
- `backend/src/gm/systemPrompt.ts` (GM system prompt)
- `packages/shared/src/gm/toolResultsSchemas.ts` (tool results)

---

## 6) Deterministic Rules (Original)
The minimal original system is **Mythweave Lite**:
- d20 checks + DC table
- advantage/disadvantage
- basic combat: initiative, attack vs defense, damage dice
- conditions (poisoned/stunned/burning)
- downed + “Last Breath”
- rest + minimal spellcasting resource (“Focus”)
- leveling + XP thresholds

See:
- `packages/shared/src/game/RULES.md`
- `packages/shared/src/game/rules.ts`

---

## 7) Server-side Validation Boundary
**The LLM must never mutate the database directly.**
It can only propose structured updates:
- server validates (constraints, existence, bounds)
- server commits as authoritative events
- snapshot updates are derived

Validation + proposeUpdates tool skeleton:
- `backend/src/game/validators/types.ts`
- `backend/src/game/validators/proposeUpdates.ts`
- `backend/src/gm/tools/proposeUpdatesTool.ts`

---

## 8) Replit Agent Prompt Pack
Copy/paste milestones from:
- `replit/REPLIT_AGENT_PROMPTS.md`

Always prepend this constraints block:
- `replit/REPLIT_AGENT_CONSTRAINTS_BLOCK.md`

---

## 9) Notes on Style Packs and Safety
- Do not reference living artists in prompts.
- Provide generic original style packs and slider mapping to adjectives/fragments.
- Add campaign content toggles:
  - rating: pg13/mature
  - no romance, no horror, fade to black
- Filter user inputs and GM outputs.

---

## 10) Deliverables Included in This Pack
- Replit prompt pack + constraints block
- Architecture overview + data model notes
- Zod schemas: GMResponse + tool calls + proposed updates
- Zod schemas: tool result envelopes
- GM system prompt
- Original ruleset (MD + TS)
- Validation engine + proposeUpdates tool skeleton
- Tool results message helper

---
