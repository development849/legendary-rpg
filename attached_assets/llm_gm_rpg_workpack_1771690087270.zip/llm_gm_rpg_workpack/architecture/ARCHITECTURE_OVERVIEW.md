# Architecture Overview

## Goals
- Tool-using LLM GM for narrative + state proposals.
- Deterministic server rules and validations.
- Event-sourced game log with derived snapshot.
- Web + mobile-first UI, PWA-friendly.
- Real-time party play + async progression.

## Chosen Approach
- One externally-exposed port for deployment simplicity.
- Fastify hosts:
  - Next.js SSR
  - REST endpoints
  - WebSocket server (rooms per party_id)
- Postgres persistence:
  - Append-only `game_events`
  - Derived `world_state` snapshot
  - Normalized tables for users/campaigns/parties, plus JSON for MVP inventories and sheets.

## Key Modules
- gm-orchestrator:
  - system prompt + JSON output contract
  - executes server tools
  - handles tool-loop until final response
- game-engine:
  - dice, checks, combat scaffolding
  - validation and state transitions
- memory:
  - rolling scene brief
  - scene summaries every N events
  - arc/chapter summaries at endpoints
  - optional embeddings/pgvector later
- realtime:
  - intent phase turn-taking
  - streaming narrative tokens
  - broadcast state updates and events
- media:
  - prompt builder only (MVP)
  - asset caching by scene hash + style pack + slider buckets

## Boundaries
- Canonical truth = DB state derived from event log.
- GM can only propose updates; server validates.
- If narration conflicts with canonical state, narration must be corrected.
