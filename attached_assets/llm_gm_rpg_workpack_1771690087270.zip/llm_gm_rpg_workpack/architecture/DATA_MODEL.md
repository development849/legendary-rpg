# Data Model Notes (MVP → V1)

## MVP tables (minimum)
- users
- campaigns (settings_json)
- parties (campaign_id, name)
- party_members (party_id, character_id, role)
- characters (user_id, campaign_id, sheet_json, appearance_json, level, xp, hp)
- inventories (character_id, items_json)  — MVP; may normalize later
- game_events (append-only)
- world_state (campaign_id, state_json, version, updated_at)

## V1+ tables (recommended)
- arcs
- quests
- relationships
- npcs
- scene_summaries
- memory_chunks (optionally with embeddings)
- media_assets

## Event sourcing
All changes should be represented in game_events with:
- campaign_id, party_id
- actor_type (player/gm/system)
- actor_id (character_id/npc_id)
- event_type
- payload_json
- created_at

world_state is derived and rebuildable.
