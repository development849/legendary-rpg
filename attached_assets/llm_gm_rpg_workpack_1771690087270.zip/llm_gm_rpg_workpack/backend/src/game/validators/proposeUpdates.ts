import {
  ProposedUpdatesSchema,
  type ProposedUpdateEvent,
  type InventoryItem,
} from "@shared/gm/schemas";
import { xpToNextLevel, maxHpGainOnLevelUp } from "@shared/game/rules";
import type {
  ValidationIssue,
  ValidationResult,
  ValidationState,
  QuestState,
  NpcState,
  RelationshipState,
} from "./types";

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function relKey(characterId: string, npcId: string): string {
  return `${characterId}:${npcId}`;
}

function stableJson(obj: unknown): string {
  if (obj === null || typeof obj !== "object") return JSON.stringify(obj);
  if (Array.isArray(obj)) return `[${obj.map(stableJson).join(",")}]`;
  const o = obj as Record<string, unknown>;
  const keys = Object.keys(o).sort();
  return `{${keys
    .map((k) => JSON.stringify(k) + ":" + stableJson(o[k]))
    .join(",")}}`;
}

function itemKey(item: InventoryItem): string {
  return `${item.name}::${item.type}::${stableJson(item.properties ?? {})}`;
}

function findItemIndicesByName(inv: InventoryItem[], name: string): number[] {
  const indices: number[] = [];
  inv.forEach((it, idx) => {
    if (it.name === name) indices.push(idx);
  });
  return indices;
}

function addOrStackItem(inv: InventoryItem[], item: InventoryItem): InventoryItem[] {
  const key = itemKey(item);
  const idx = inv.findIndex((it) => itemKey(it) === key);
  if (idx >= 0) {
    const copy = inv.slice();
    copy[idx] = { ...copy[idx], qty: copy[idx].qty + item.qty };
    return copy;
  }
  return inv.concat([item]);
}

function removeItemByNameQty(
  inv: InventoryItem[],
  itemName: string,
  qty: number
): { ok: boolean; inventory: InventoryItem[] } {
  let remaining = qty;
  const copy = inv.map((x) => ({ ...x }));

  const indices = findItemIndicesByName(copy, itemName);
  if (indices.length === 0) return { ok: false, inventory: inv };

  for (const idx of indices) {
    if (remaining <= 0) break;
    const available = copy[idx].qty;
    const take = Math.min(available, remaining);
    copy[idx].qty -= take;
    remaining -= take;
  }

  if (remaining > 0) return { ok: false, inventory: inv };
  return { ok: true, inventory: copy.filter((it) => it.qty > 0) };
}

function deepCloneState(state: ValidationState): ValidationState {
  return {
    campaign_id: state.campaign_id,
    party_id: state.party_id,
    characters: Object.fromEntries(
      Object.entries(state.characters).map(([id, c]) => [
        id,
        {
          ...c,
          inventory: c.inventory.map((it) => ({
            ...it,
            properties: { ...(it.properties ?? {}) },
          })),
        },
      ])
    ),
    quests: Object.fromEntries(
      Object.entries(state.quests).map(([id, q]) => [id, { ...q }])
    ),
    npcs: Object.fromEntries(
      Object.entries(state.npcs).map(([id, n]) => [id, { ...n }])
    ),
    arcs: Object.fromEntries(
      Object.entries(state.arcs).map(([id, a]) => [id, { ...a }])
    ),
    relationships: Object.fromEntries(
      Object.entries(state.relationships).map(([k, r]) => [
        k,
        { ...r, tags: [...r.tags] },
      ])
    ),
    scene: { ...state.scene },
  };
}

export interface ValidateOptions {
  atomic?: boolean; // default true
}

export function validateProposedUpdates(
  rawUpdates: unknown,
  state: ValidationState,
  options: ValidateOptions = {}
): ValidationResult {
  const atomic = options.atomic ?? true;
  const updates = ProposedUpdatesSchema.parse(rawUpdates);

  const sim = deepCloneState(state);
  const accepted: Array<{ index: number; normalized_event: ProposedUpdateEvent }> =
    [];
  const rejected: ValidationIssue[] = [];

  const reject = (issue: ValidationIssue) => rejected.push(issue);

  const seenKeys = new Set<string>();

  updates.events.forEach((event, index) => {
    const softKey =
      event.event_type === "HP_CHANGED"
        ? `HP_CHANGED:${event.payload.character_id}`
        : event.event_type === "LEVEL_UP"
        ? `LEVEL_UP:${event.payload.character_id}`
        : event.event_type === "SCENE_ADVANCED"
        ? `SCENE_ADVANCED`
        : null;

    if (softKey && seenKeys.has(softKey)) {
      reject({
        index,
        event_type: event.event_type,
        code: "DUPLICATE_OR_CONFLICTING",
        message: `Conflicting duplicate update detected: ${softKey}. Combine into one event.`,
      });
      return;
    }
    if (softKey) seenKeys.add(softKey);

    switch (event.event_type) {
      case "HP_CHANGED": {
        const { character_id, delta, new_hp } = event.payload;
        const ch = sim.characters[character_id];
        if (!ch) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_CHARACTER",
            message: `Unknown character_id: ${character_id}`,
            path: ["payload", "character_id"],
          });
          return;
        }

        const computed = ch.hp_current + delta;
        if (computed < 0 || computed > ch.hp_max) {
          reject({
            index,
            event_type: event.event_type,
            code: "HP_OUT_OF_BOUNDS",
            message: `HP would become ${computed} but must be within 0..${ch.hp_max}.`,
            path: ["payload", "delta"],
          });
          return;
        }

        if (typeof new_hp === "number" && new_hp !== computed) {
          reject({
            index,
            event_type: event.event_type,
            code: "CONSTRAINT_VIOLATION",
            message: `new_hp (${new_hp}) does not match computed HP (${computed}).`,
            path: ["payload", "new_hp"],
          });
          return;
        }

        const normalized: ProposedUpdateEvent = {
          ...event,
          payload: { ...event.payload, new_hp: computed },
        } as ProposedUpdateEvent;

        ch.hp_current = computed;
        accepted.push({ index, normalized_event: normalized });
        return;
      }

      case "XP_GRANTED": {
        const { character_id, amount } = event.payload;
        const ch = sim.characters[character_id];
        if (!ch) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_CHARACTER",
            message: `Unknown character_id: ${character_id}`,
            path: ["payload", "character_id"],
          });
          return;
        }
        if (amount <= 0) {
          reject({
            index,
            event_type: event.event_type,
            code: "XP_INVALID",
            message: `XP amount must be > 0`,
            path: ["payload", "amount"],
          });
          return;
        }
        ch.xp += amount;
        accepted.push({ index, normalized_event: event });
        return;
      }

      case "LEVEL_UP": {
        const { character_id, new_level } = event.payload;
        const ch = sim.characters[character_id];
        if (!ch) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_CHARACTER",
            message: `Unknown character_id: ${character_id}`,
            path: ["payload", "character_id"],
          });
          return;
        }

        if (new_level !== ch.level + 1) {
          reject({
            index,
            event_type: event.event_type,
            code: "LEVEL_UP_INVALID",
            message: `new_level must be exactly current_level+1. Current=${ch.level}, proposed=${new_level}.`,
            path: ["payload", "new_level"],
          });
          return;
        }

        const needed = xpToNextLevel(ch.level);
        if (ch.xp < needed) {
          reject({
            index,
            event_type: event.event_type,
            code: "LEVEL_UP_INVALID",
            message: `Insufficient XP to level up. Need ${needed} XP, have ${ch.xp}.`,
            path: ["payload", "character_id"],
          });
          return;
        }

        const hpGain = maxHpGainOnLevelUp(ch.class_id);
        ch.level = new_level;
        ch.hp_max += hpGain;
        ch.hp_current = clamp(ch.hp_current + hpGain, 0, ch.hp_max);

        accepted.push({ index, normalized_event: event });
        return;
      }

      case "ITEM_GRANTED": {
        const { character_id, item } = event.payload;
        const ch = sim.characters[character_id];
        if (!ch) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_CHARACTER",
            message: `Unknown character_id: ${character_id}`,
            path: ["payload", "character_id"],
          });
          return;
        }
        if (item.qty <= 0) {
          reject({
            index,
            event_type: event.event_type,
            code: "CONSTRAINT_VIOLATION",
            message: `Granted item qty must be >= 1.`,
            path: ["payload", "item", "qty"],
          });
          return;
        }

        ch.inventory = addOrStackItem(ch.inventory, item);
        accepted.push({ index, normalized_event: event });
        return;
      }

      case "ITEM_REMOVED": {
        const { character_id, item_name, qty } = event.payload;
        const ch = sim.characters[character_id];
        if (!ch) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_CHARACTER",
            message: `Unknown character_id: ${character_id}`,
            path: ["payload", "character_id"],
          });
          return;
        }

        const existingIndices = findItemIndicesByName(ch.inventory, item_name);
        if (existingIndices.length === 0) {
          reject({
            index,
            event_type: event.event_type,
            code: "ITEM_NOT_FOUND",
            message: `Character does not have item named "${item_name}".`,
            path: ["payload", "item_name"],
          });
          return;
        }

        const res = removeItemByNameQty(ch.inventory, item_name, qty);
        if (!res.ok) {
          reject({
            index,
            event_type: event.event_type,
            code: "INSUFFICIENT_ITEM_QTY",
            message: `Not enough quantity of "${item_name}" to remove ${qty}.`,
            path: ["payload", "qty"],
          });
          return;
        }

        ch.inventory = res.inventory;
        accepted.push({ index, normalized_event: event });
        return;
      }

      case "QUEST_STAGE_CHANGED": {
        const { quest_id, title, summary, stage, status } = event.payload as any;

        let q = sim.quests[quest_id];
        if (!q) {
          if (typeof title === "string" && title.length > 0) {
            const created: QuestState = {
              quest_id,
              party_id: sim.party_id,
              title,
              summary,
              status: status ?? "active",
              stage,
            };
            sim.quests[quest_id] = created;
            accepted.push({ index, normalized_event: event });
            return;
          }

          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_QUEST",
            message: `Unknown quest_id: ${quest_id}. Provide title to create, or reference an existing quest.`,
            path: ["payload", "quest_id"],
          });
          return;
        }

        q.stage = stage;
        if (status) q.status = status;
        accepted.push({ index, normalized_event: event });
        return;
      }

      case "RELATIONSHIP_CHANGED": {
        const {
          character_id,
          npc_id,
          npc_name,
          npc_description,
          delta,
          new_score,
          tags,
          notes,
        } = event.payload as any;

        const ch = sim.characters[character_id];
        if (!ch) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_CHARACTER",
            message: `Unknown character_id: ${character_id}`,
            path: ["payload", "character_id"],
          });
          return;
        }

        let npc = sim.npcs[npc_id];
        if (!npc) {
          if (typeof npc_name === "string" && npc_name.length > 0) {
            const created: NpcState = {
              npc_id,
              party_id: sim.party_id,
              name: npc_name,
              description: npc_description,
            };
            sim.npcs[npc_id] = created;
            npc = created;
          } else {
            reject({
              index,
              event_type: event.event_type,
              code: "INVALID_NPC",
              message: `Unknown npc_id: ${npc_id}. Provide npc_name to create, or reference an existing NPC.`,
              path: ["payload", "npc_id"],
            });
            return;
          }
        }

        const key = relKey(character_id, npc_id);
        const current = sim.relationships[key] ?? {
          character_id,
          npc_id,
          score: 0,
          tags: [],
        };

        const computed = clamp(current.score + delta, -100, 100);

        if (typeof new_score === "number" && new_score !== computed) {
          reject({
            index,
            event_type: event.event_type,
            code: "CONSTRAINT_VIOLATION",
            message: `new_score (${new_score}) does not match computed score (${computed}).`,
            path: ["payload", "new_score"],
          });
          return;
        }

        const normalized: ProposedUpdateEvent = {
          ...event,
          payload: { ...event.payload, new_score: computed },
        } as ProposedUpdateEvent;

        sim.relationships[key] = {
          character_id,
          npc_id,
          score: computed,
          tags: Array.isArray(tags) ? tags : current.tags,
          notes: typeof notes === "string" ? notes : current.notes,
        } as RelationshipState;

        accepted.push({ index, normalized_event: normalized });
        return;
      }

      case "SCENE_ADVANCED": {
        sim.scene = {
          title: event.payload.new_scene_title,
          location: event.payload.new_location,
          immediate_threat: null,
          time_pressure: null,
        };
        accepted.push({ index, normalized_event: event });
        return;
      }

      case "CHAPTER_ENDED": {
        const { arc_id } = event.payload;
        const arc = sim.arcs[arc_id];
        if (!arc) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_ARC",
            message: `Unknown arc_id: ${arc_id}`,
            path: ["payload", "arc_id"],
          });
          return;
        }

        for (let i = 0; i < event.payload.rewards.items.length; i++) {
          const it = event.payload.rewards.items[i];
          if (!sim.characters[it.character_id]) {
            reject({
              index,
              event_type: event.event_type,
              code: "INVALID_CHARACTER",
              message: `Reward references unknown character_id: ${it.character_id}`,
              path: ["payload", "rewards", "items", i, "character_id"],
            });
            return;
          }
        }

        accepted.push({ index, normalized_event: event });
        return;
      }

      case "ARC_UPDATED": {
        const { arc_id, status } = event.payload;
        const arc = sim.arcs[arc_id];
        if (!arc) {
          reject({
            index,
            event_type: event.event_type,
            code: "INVALID_ARC",
            message: `Unknown arc_id: ${arc_id}`,
            path: ["payload", "arc_id"],
          });
          return;
        }
        arc.status = status;
        accepted.push({ index, normalized_event: event });
        return;
      }

      default: {
        reject({
          index,
          event_type: (event as any).event_type ?? "UNKNOWN",
          code: "UNKNOWN_EVENT",
          message: `Unknown event type.`,
        });
        return;
      }
    }
  });

  const ok = rejected.length === 0;

  return {
    ok: atomic ? ok : true,
    atomic,
    accepted,
    rejected,
    simulated_state: sim,
  };
}
