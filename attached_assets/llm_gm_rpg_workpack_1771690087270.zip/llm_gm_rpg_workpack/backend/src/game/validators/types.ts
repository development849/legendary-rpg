import type { ProposedUpdateEvent, InventoryItem } from "@shared/gm/schemas";

export type ValidationIssueCode =
  | "UNKNOWN_EVENT"
  | "INVALID_CHARACTER"
  | "INVALID_NPC"
  | "INVALID_QUEST"
  | "INVALID_ARC"
  | "NOT_IN_PARTY"
  | "HP_OUT_OF_BOUNDS"
  | "XP_INVALID"
  | "LEVEL_UP_INVALID"
  | "INSUFFICIENT_ITEM_QTY"
  | "ITEM_NOT_FOUND"
  | "DUPLICATE_OR_CONFLICTING"
  | "CONSTRAINT_VIOLATION"
  | "VALIDATION_FAILED";

export interface ValidationIssue {
  index: number;
  event_type: string;
  code: ValidationIssueCode;
  message: string;
  path?: Array<string | number>;
}

export interface CharacterState {
  character_id: string;
  party_id: string;
  class_id: "fighter" | "rogue" | "wizard" | "cleric";
  level: number;
  xp: number;
  hp_current: number;
  hp_max: number;
  inventory: InventoryItem[];
}

export interface QuestState {
  quest_id: string;
  party_id: string;
  title: string;
  summary?: string;
  status: "active" | "completed" | "failed";
  stage: string;
}

export interface NpcState {
  npc_id: string;
  party_id: string;
  name: string;
  description?: string;
}

export interface ArcState {
  arc_id: string;
  party_id: string;
  status: "planned" | "active" | "completed" | "abandoned";
}

export interface RelationshipState {
  character_id: string;
  npc_id: string;
  score: number; // -100..100
  tags: string[];
  notes?: string;
}

export interface SceneState {
  title: string;
  location: string;
  immediate_threat: string | null;
  time_pressure: string | null;
}

export interface ValidationState {
  campaign_id: string;
  party_id: string;
  characters: Record<string, CharacterState>;
  quests: Record<string, QuestState>;
  npcs: Record<string, NpcState>;
  arcs: Record<string, ArcState>;
  relationships: Record<string, RelationshipState>; // key = `${character_id}:${npc_id}`
  scene: SceneState;
}

export interface ValidationResult {
  ok: boolean;
  atomic: boolean;
  accepted: Array<{ index: number; normalized_event: ProposedUpdateEvent }>;
  rejected: ValidationIssue[];
  simulated_state: ValidationState;
}
