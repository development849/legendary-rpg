import { ToolResultsMessageSchema, type ToolResult } from "@shared/gm/toolResultsSchemas";

export function buildToolResultsMessage(toolResults: ToolResult[]) {
  return ToolResultsMessageSchema.parse({
    tool_results: toolResults,
  });
}
