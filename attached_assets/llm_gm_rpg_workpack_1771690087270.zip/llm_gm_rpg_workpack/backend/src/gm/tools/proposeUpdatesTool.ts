import { ProposeUpdatesResultSchema } from "@shared/gm/toolResultsSchemas";
import type { ToolResult } from "@shared/gm/toolResultsSchemas";
import type { ValidationState } from "../../game/validators/types";
import { validateProposedUpdates } from "../../game/validators/proposeUpdates";

// Implement these using your DB layer:
async function loadValidationState(campaignId: string, partyId: string): Promise<ValidationState> {
  // TODO: Load from world_state snapshot + relevant tables (characters/inventory/arcs/quests/npcs/relationships)
  // Keep it deterministic: this is the canonical authority used for validation.
  throw new Error("loadValidationState not implemented");
}

async function commitGameEventsAtomic(opts: {
  campaignId: string;
  partyId: string;
  normalizedEvents: Array<{ event_type: string; payload: any }>;
}): Promise<{ gameEventIds: string[]; newWorldStateVersion?: number }> {
  // TODO: DB transaction:
  // - insert each into game_events (append-only)
  // - update derived world_state snapshot + version bump
  // - return inserted ids + new version
  throw new Error("commitGameEventsAtomic not implemented");
}

export async function proposeUpdatesTool(args: {
  campaign_id: string;
  party_id: string;
  updates_json: unknown;
  atomic?: boolean;
}): Promise<ToolResult> {
  try {
    const atomic = args.atomic ?? true;
    const state = await loadValidationState(args.campaign_id, args.party_id);

    const validation = validateProposedUpdates(args.updates_json, state, { atomic });

    if (atomic && validation.rejected.length > 0) {
      const result = ProposeUpdatesResultSchema.parse({
        atomic: true,
        accepted: validation.accepted,
        rejected: validation.rejected,
        applied: false,
        game_event_ids: [],
      });

      return { name: "proposeUpdates", ok: true, result };
    }

    // Commit normalized events (atomic transaction)
    const normalizedEvents = validation.accepted.map((x) => ({
      event_type: x.normalized_event.event_type,
      payload: x.normalized_event.payload,
    }));

    const commit = await commitGameEventsAtomic({
      campaignId: args.campaign_id,
      partyId: args.party_id,
      normalizedEvents,
    });

    const result = ProposeUpdatesResultSchema.parse({
      atomic: atomic,
      accepted: validation.accepted,
      rejected: validation.rejected,
      applied: true,
      game_event_ids: commit.gameEventIds,
      new_world_state_version: commit.newWorldStateVersion,
    });

    return { name: "proposeUpdates", ok: true, result };
  } catch (err: any) {
    return {
      name: "proposeUpdates",
      ok: false,
      error: {
        code: "PROPOSE_UPDATES_FAILED",
        message: err?.message ?? "Unknown error",
        details: { stack: err?.stack },
      },
    };
  }
}
