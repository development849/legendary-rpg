# Minimal Ruleset (Original) — “Mythweave Lite”

This is a lightweight, D20-based fantasy ruleset designed for fast online play with an LLM GM.
It is intentionally simple, deterministic, and easy to validate server-side.

## 1) Core Stats
Characters have 6 Abilities (scores typically 8–18):
- **Might**: strength, lifting, melee power
- **Agility**: reflexes, balance, stealth, aim
- **Endurance**: toughness, stamina, resisting harm
- **Intellect**: reasoning, lore, investigation, spellcraft
- **Will**: focus, courage, resisting fear/compulsion, divine channeling
- **Presence**: charm, intimidation, leadership, deception

**Modifier** = floor((score − 10) / 2)

## 2) Skills
Skills are checks you can be proficient in. Suggested set:
- Athletics (Might)
- Acrobatics (Agility)
- Stealth (Agility)
- Thievery (Agility)
- Survival (Endurance)
- Medicine (Endurance)
- Lore (Intellect)
- Investigation (Intellect)
- Insight (Will)
- Persuasion (Presence)
- Deception (Presence)
- Intimidation (Presence)

If you’re proficient in a skill, add **Proficiency Bonus**.

## 3) Proficiency Bonus
Proficiency Bonus scales slowly:
- Level 1–4: +2
- Level 5–8: +3
- Level 9–12: +4
- Level 13+: +5 (optional future)

## 4) Checks & Difficulty
When an outcome is uncertain and meaningful, roll a **d20**:

**d20 + Ability Mod + (Proficiency Bonus if proficient) + situational modifiers**

Difficulty Classes (DC):
- DC 8: trivial
- DC 11: easy
- DC 14: standard
- DC 17: hard
- DC 20: extreme
- DC 23: legendary

### Advantage / Disadvantage
If you have advantage, roll 2d20 and take the higher.
If you have disadvantage, roll 2d20 and take the lower.
One advantage and one disadvantage cancel to normal.

## 5) Combat Basics
Combat is turn-based when danger is immediate.

### 5.1 Initiative
Each combatant rolls:
**Initiative = d20 + Agility Mod**

### 5.2 Turn
On your turn, you can do:
- **1 Action** (attack, cast, dash, assist, interact meaningfully)
- **1 Move** (change position / close distance / retreat)
- **1 Quick** (draw item, short shout, minor interaction)

The GM may allow creative alternatives.

### 5.3 Defense
Defense is a target number to hit.
**Defense = 10 + Armor Bonus + Shield Bonus + Agility Mod (if armor allows)**

Armor can cap Agility contribution (light: full, medium: max +2, heavy: +0).

### 5.4 Attacking
To hit:
**Attack Roll = d20 + relevant mod + proficiency (if trained with weapon)**

If Attack Roll ≥ target Defense, it hits.

**Damage**:
- Light weapon: 1d6 + mod
- Medium weapon: 1d8 + mod
- Heavy weapon: 1d10 + mod
- Ranged weapon: 1d8 + mod
- Simple spell: 1d10 + caster mod (Intellect or Will depending on class)

**Critical Hit**: natural 20 doubles the damage dice (not modifiers).
**Fumble**: natural 1 is an automatic miss (no extra punishment by default).

### 5.5 Conditions (MVP)
Conditions are short tags with simple effects:
- **Poisoned**: disadvantage on physical checks/attacks
- **Stunned**: lose your next Action
- **Burning**: take 1d4 damage at start of turn until extinguished (Action to end)

## 6) HP, Downed, and “Last Breath”
When HP reaches 0:
- You become **Downed** (can’t take Actions; can speak faintly).
- At the start of your turns, roll a **Last Breath** check:
  - **d20 ≥ 10** = success
  - **d20 < 10** = failure
- 3 successes: stabilize and regain 1 HP after combat ends (or sooner if aided).
- 3 failures: you die.

Allies can help:
- **Medicine check DC 14** to stabilize (no roll needed if they have a proper healer’s kit).
- Any healing restores HP immediately and ends Downed.

## 7) Rest & Recovery
- **Short Rest** (safe pause): regain one “Breather”:
  - Spend 1 Breather to heal **1d8 + Endurance Mod** (once per short rest).
- **Long Rest** (safe sleep): restore HP to max and refresh per-rest abilities/resources.

## 8) Spellcasting Resource (MVP)
Casters use **Focus** (points).
- Wizard: Focus Max = 2 + level
- Cleric: Focus Max = 2 + level
- Focus refreshes on Long Rest.
- Simple spells cost 1 Focus; stronger spells cost 2+ Focus (later).

## 9) Progression
Characters gain XP for meaningful play:
- Minor: 10–25 XP
- Standard scene win/solve: 50–80 XP
- Major milestone / chapter end: 150–250 XP

**Level up** when total XP meets threshold:
- XP needed to reach next level = **150 + 50 × current level**
Example: L1→2: 200 XP, L2→3: 250 XP, L3→4: 300 XP, etc.

On Level Up:
- Increase Max HP by class:
  - Fighter +6
  - Rogue +5
  - Wizard +4
  - Cleric +5
- Choose ONE:
  - +1 to an Ability (max 18 at MVP)
  - gain proficiency in a new Skill
  - choose a Feat (optional at levels 3/6/9)

## 10) Starter Classes (MVP)
### Fighter
- Feature: **Second Wind** (1/Short Rest) heal 1d10 + level

### Rogue
- Feature: **Opportunist** (1/turn) deal +1d6 damage if you had advantage OR an ally is engaging the target in melee

### Wizard
- Focus resource; starter spells are narrative templates, validated by Focus costs.

### Cleric
- Focus resource; starter miracles are narrative templates, validated by Focus costs.

## 11) Economy & Loot (MVP)
- Currency: gold (gp) as integer.
- Items have qty and properties.
- Loot is granted only through validated ITEM_GRANTED updates.
