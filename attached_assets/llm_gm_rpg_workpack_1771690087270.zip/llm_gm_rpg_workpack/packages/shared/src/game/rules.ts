export type Ability =
  | "might"
  | "agility"
  | "endurance"
  | "intellect"
  | "will"
  | "presence";

export type Skill =
  | "athletics"
  | "acrobatics"
  | "stealth"
  | "thievery"
  | "survival"
  | "medicine"
  | "lore"
  | "investigation"
  | "insight"
  | "persuasion"
  | "deception"
  | "intimidation";

export type ClassId = "fighter" | "rogue" | "wizard" | "cleric";

export const ABILITIES: Record<Ability, { label: string; description: string }> =
  {
    might: { label: "Might", description: "Strength, lifting, melee power" },
    agility: { label: "Agility", description: "Reflexes, balance, stealth, aim" },
    endurance: { label: "Endurance", description: "Stamina, toughness, resisting harm" },
    intellect: { label: "Intellect", description: "Reason, lore, investigation, spellcraft" },
    will: { label: "Will", description: "Focus, courage, resisting fear/compulsion" },
    presence: { label: "Presence", description: "Charm, intimidation, leadership, deception" },
  };

export const SKILLS: Array<{
  id: Skill;
  label: string;
  ability: Ability;
}> = [
  { id: "athletics", label: "Athletics", ability: "might" },
  { id: "acrobatics", label: "Acrobatics", ability: "agility" },
  { id: "stealth", label: "Stealth", ability: "agility" },
  { id: "thievery", label: "Thievery", ability: "agility" },
  { id: "survival", label: "Survival", ability: "endurance" },
  { id: "medicine", label: "Medicine", ability: "endurance" },
  { id: "lore", label: "Lore", ability: "intellect" },
  { id: "investigation", label: "Investigation", ability: "intellect" },
  { id: "insight", label: "Insight", ability: "will" },
  { id: "persuasion", label: "Persuasion", ability: "presence" },
  { id: "deception", label: "Deception", ability: "presence" },
  { id: "intimidation", label: "Intimidation", ability: "presence" },
];

export const DC = {
  TRIVIAL: 8,
  EASY: 11,
  STANDARD: 14,
  HARD: 17,
  EXTREME: 20,
  LEGENDARY: 23,
} as const;

export function abilityMod(score: number): number {
  return Math.floor((score - 10) / 2);
}

export function proficiencyBonus(level: number): number {
  if (level >= 13) return 5;
  if (level >= 9) return 4;
  if (level >= 5) return 3;
  return 2;
}

export function xpToNextLevel(currentLevel: number): number {
  return 150 + 50 * currentLevel;
}

export function maxHpGainOnLevelUp(classId: ClassId): number {
  switch (classId) {
    case "fighter":
      return 6;
    case "rogue":
      return 5;
    case "wizard":
      return 4;
    case "cleric":
      return 5;
    default:
      return 5;
  }
}

export const WEAPONS = {
  light: { damageDie: "d6", label: "Light Weapon" },
  medium: { damageDie: "d8", label: "Medium Weapon" },
  heavy: { damageDie: "d10", label: "Heavy Weapon" },
  ranged: { damageDie: "d8", label: "Ranged Weapon" },
} as const;

export type WeaponCategory = keyof typeof WEAPONS;

export type ConditionId = "poisoned" | "stunned" | "burning";

export const CONDITIONS: Record<
  ConditionId,
  { label: string; effect: string }
> = {
  poisoned: {
    label: "Poisoned",
    effect: "Disadvantage on physical checks and attacks.",
  },
  stunned: {
    label: "Stunned",
    effect: "Lose your next Action.",
  },
  burning: {
    label: "Burning",
    effect: "Take 1d4 damage at start of turn until extinguished (Action).",
  },
};

export const CLASSES: Record<
  ClassId,
  {
    label: string;
    role: string;
    primaryAbility: Ability;
    focusMaxFormula?: (level: number) => number;
    features: Array<{ id: string; name: string; usage: string; rules: string }>;
    startingKit: Array<{
      name: string;
      type: "weapon" | "armor" | "consumable" | "tool" | "misc";
      qty: number;
      properties?: Record<string, string | number | boolean | null>;
    }>;
  }
> = {
  fighter: {
    label: "Fighter",
    role: "Frontliner / protector",
    primaryAbility: "might",
    features: [
      {
        id: "second_wind",
        name: "Second Wind",
        usage: "1/Short Rest",
        rules: "Heal 1d10 + level.",
      },
    ],
    startingKit: [
      { name: "Medium Weapon", type: "weapon", qty: 1, properties: { cat: "medium" } },
      { name: "Shield", type: "armor", qty: 1, properties: { shield: true, bonus: 2 } },
      { name: "Travel Rations", type: "consumable", qty: 5 },
      { name: "Torch", type: "tool", qty: 3 },
    ],
  },

  rogue: {
    label: "Rogue",
    role: "Scout / skirmisher",
    primaryAbility: "agility",
    features: [
      {
        id: "opportunist",
        name: "Opportunist",
        usage: "1/turn",
        rules:
          "Add +1d6 damage when you have advantage OR an ally is engaging the target in melee.",
      },
    ],
    startingKit: [
      { name: "Light Weapon", type: "weapon", qty: 1, properties: { cat: "light" } },
      { name: "Ranged Weapon", type: "weapon", qty: 1, properties: { cat: "ranged" } },
      { name: "Lockpicks", type: "tool", qty: 1 },
      { name: "Smoke Vial", type: "consumable", qty: 2 },
    ],
  },

  wizard: {
    label: "Wizard",
    role: "Arcane caster / control",
    primaryAbility: "intellect",
    focusMaxFormula: (level) => 2 + level,
    features: [
      {
        id: "arcane_focus",
        name: "Arcane Focus",
        usage: "Resource",
        rules: "You have Focus points used to cast spells. Refresh on Long Rest.",
      },
    ],
    startingKit: [
      { name: "Arcane Focus Charm", type: "tool", qty: 1 },
      { name: "Spellbook", type: "tool", qty: 1 },
      { name: "Travel Rations", type: "consumable", qty: 5 },
      { name: "Torch", type: "tool", qty: 2 },
    ],
  },

  cleric: {
    label: "Cleric",
    role: "Support / divine caster",
    primaryAbility: "will",
    focusMaxFormula: (level) => 2 + level,
    features: [
      {
        id: "sacred_focus",
        name: "Sacred Focus",
        usage: "Resource",
        rules: "You have Focus points used to invoke miracles. Refresh on Long Rest.",
      },
    ],
    startingKit: [
      { name: "Medium Weapon", type: "weapon", qty: 1, properties: { cat: "medium" } },
      { name: "Holy Symbol", type: "tool", qty: 1 },
      { name: "Bandages", type: "consumable", qty: 3, properties: { heal: 4 } },
      { name: "Travel Rations", type: "consumable", qty: 5 },
    ],
  },
};
