import { z } from "zod";

/**
 * Core primitives
 */
export const IdString = z.string().min(1, "Expected a non-empty id string");

export const Float01 = z
  .number()
  .finite()
  .min(0, "Must be between 0 and 1")
  .max(1, "Must be between 0 and 1");

export const UiModeSchema = z.enum(["fast", "balanced", "cinematic"]);
export type UiMode = z.infer<typeof UiModeSchema>;

export const ResponsePhaseSchema = z.enum(["tool_request", "final"]);
export type ResponsePhase = z.infer<typeof ResponsePhaseSchema>;

/**
 * Dice
 */
export const AdvantageStateSchema = z.enum([
  "normal",
  "advantage",
  "disadvantage",
]);
export type AdvantageState = z.infer<typeof AdvantageStateSchema>;

export const DieSchema = z.enum(["d4", "d6", "d8", "d10", "d12", "d20", "d100"]);
export type Die = z.infer<typeof DieSchema>;

export const DiceRollSpecSchema = z
  .object({
    die: DieSchema,
    count: z.number().int().min(1).max(20),
    modifier: z.number().int().min(-100).max(100).default(0),
    advantageState: AdvantageStateSchema.default("normal"),
    label: z.string().min(1).max(80).optional(),
  })
  .strict();
export type DiceRollSpec = z.infer<typeof DiceRollSpecSchema>;

/**
 * Inventory items (MVP-level)
 */
export const ItemTypeSchema = z.enum([
  "weapon",
  "armor",
  "consumable",
  "tool",
  "quest",
  "treasure",
  "misc",
]);
export type ItemType = z.infer<typeof ItemTypeSchema>;

export const ItemPropertyValueSchema = z.union([
  z.string(),
  z.number(),
  z.boolean(),
  z.null(),
]);

export const InventoryItemSchema = z
  .object({
    name: z.string().min(1).max(100),
    type: ItemTypeSchema,
    qty: z.number().int().min(1).max(999),
    properties: z.record(z.string(), ItemPropertyValueSchema).default({}),
  })
  .strict();
export type InventoryItem = z.infer<typeof InventoryItemSchema>;

/**
 * Scene framing (required every turn)
 */
export const SceneSchema = z
  .object({
    title: z.string().min(1).max(120),
    location: z.string().min(1).max(120),
    immediate_threat: z.string().min(1).max(240).nullable(),
    time_pressure: z.string().min(1).max(240).nullable(),
  })
  .strict();
export type Scene = z.infer<typeof SceneSchema>;

/**
 * Art direction — generic / original style packs only
 */
export const StylePackSchema = z.enum([
  "luminous_painterly_fantasy",
  "dark_inked_gothic",
  "storybook_watercolor",
  "crisp_cinematic_concept",
  "ancient_tapestry_mythic",
]);
export type StylePack = z.infer<typeof StylePackSchema>;

export const StyleSlidersSchema = z
  .object({
    palette: Float01, // cool↔warm descriptor mapping
    contrast: Float01, // misty↔high-contrast mapping
    line_sharpness: Float01, // soft↔crisp mapping
    detail: Float01, // minimal↔ornate mapping
  })
  .strict();
export type StyleSliders = z.infer<typeof StyleSlidersSchema>;

export const BackgroundMediaPromptSchema = z
  .object({
    prompt: z.string().min(1).max(1200),
    style_pack: StylePackSchema,
    sliders: StyleSlidersSchema,
  })
  .strict();
export type BackgroundMediaPrompt = z.infer<typeof BackgroundMediaPromptSchema>;

export const AmbienceMediaPromptSchema = z
  .object({
    prompt: z.string().min(1).max(600),
    intensity: Float01,
  })
  .strict();
export type AmbienceMediaPrompt = z.infer<typeof AmbienceMediaPromptSchema>;

export const MediaPromptsSchema = z
  .object({
    background: BackgroundMediaPromptSchema,
    ambience: AmbienceMediaPromptSchema,
    // Optional hint for later TTS voicing ("gravelly old veteran", "bright curious apprentice")
    npc_voice_hint: z.string().min(1).max(200).nullable().optional(),
  })
  .strict();
export type MediaPrompts = z.infer<typeof MediaPromptsSchema>;

/**
 * UI suggestions (optional)
 */
export const UiSuggestionsSchema = z
  .object({
    quick_actions: z.array(z.string().min(1).max(30)).max(12).default([]),
    mode: UiModeSchema.default("balanced"),
  })
  .strict();
export type UiSuggestions = z.infer<typeof UiSuggestionsSchema>;

/**
 * Proposed Updates (structured state deltas)
 * These become validated + transformed into authoritative game_events by the server.
 */
export const ProposedHpChangedSchema = z
  .object({
    event_type: z.literal("HP_CHANGED"),
    payload: z
      .object({
        character_id: IdString,
        delta: z.number().int().min(-999).max(999),
        new_hp: z.number().int().min(0).max(999).optional(),
        reason: z.string().min(1).max(200).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedXpGrantedSchema = z
  .object({
    event_type: z.literal("XP_GRANTED"),
    payload: z
      .object({
        character_id: IdString,
        amount: z.number().int().min(1).max(100000),
        reason: z.string().min(1).max(200).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedLevelUpSchema = z
  .object({
    event_type: z.literal("LEVEL_UP"),
    payload: z
      .object({
        character_id: IdString,
        new_level: z.number().int().min(1).max(30),
        notes: z.string().min(1).max(300).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedItemGrantedSchema = z
  .object({
    event_type: z.literal("ITEM_GRANTED"),
    payload: z
      .object({
        character_id: IdString,
        item: InventoryItemSchema,
        reason: z.string().min(1).max(200).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedItemRemovedSchema = z
  .object({
    event_type: z.literal("ITEM_REMOVED"),
    payload: z
      .object({
        character_id: IdString,
        item_name: z.string().min(1).max(100),
        qty: z.number().int().min(1).max(999),
        reason: z.string().min(1).max(200).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedQuestStageChangedSchema = z
  .object({
    event_type: z.literal("QUEST_STAGE_CHANGED"),
    payload: z
      .object({
        quest_id: IdString,
        // Optional: allow create-on-first-reference
        title: z.string().min(1).max(120).optional(),
        summary: z.string().min(1).max(400).optional(),

        stage: z.string().min(1).max(80),
        status: z.enum(["active", "completed", "failed"]).optional(),
        notes: z.string().min(1).max(300).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedRelationshipChangedSchema = z
  .object({
    event_type: z.literal("RELATIONSHIP_CHANGED"),
    payload: z
      .object({
        character_id: IdString,
        npc_id: IdString,

        // Optional: allow create-on-first-reference
        npc_name: z.string().min(1).max(80).optional(),
        npc_description: z.string().min(1).max(240).optional(),

        delta: z.number().int().min(-100).max(100),
        new_score: z.number().int().min(-100).max(100).optional(),
        tags: z.array(z.string().min(1).max(30)).max(10).optional(),
        notes: z.string().min(1).max(300).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedSceneAdvancedSchema = z
  .object({
    event_type: z.literal("SCENE_ADVANCED"),
    payload: z
      .object({
        new_scene_title: z.string().min(1).max(120),
        new_location: z.string().min(1).max(120),
        brief: z.string().min(1).max(400),
      })
      .strict(),
  })
  .strict();

export const ProposedChapterEndedSchema = z
  .object({
    event_type: z.literal("CHAPTER_ENDED"),
    payload: z
      .object({
        arc_id: IdString,
        chapter_title: z.string().min(1).max(120),
        recap: z.string().min(1).max(1200),
        consequences: z.array(z.string().min(1).max(200)).max(12).default([]),
        rewards: z
          .object({
            xp_each: z.number().int().min(0).max(100000).default(0),
            items: z
              .array(
                z
                  .object({
                    character_id: IdString,
                    item: InventoryItemSchema,
                  })
                  .strict()
              )
              .max(20)
              .default([]),
          })
          .strict(),
        next_hook: z.string().min(1).max(500),
      })
      .strict(),
  })
  .strict();

export const ProposedArcUpdatedSchema = z
  .object({
    event_type: z.literal("ARC_UPDATED"),
    payload: z
      .object({
        arc_id: IdString,
        status: z.enum(["planned", "active", "completed", "abandoned"]),
        outcome_summary: z.string().min(1).max(800).optional(),
      })
      .strict(),
  })
  .strict();

export const ProposedUpdateEventSchema = z.discriminatedUnion("event_type", [
  ProposedHpChangedSchema,
  ProposedXpGrantedSchema,
  ProposedLevelUpSchema,
  ProposedItemGrantedSchema,
  ProposedItemRemovedSchema,
  ProposedQuestStageChangedSchema,
  ProposedRelationshipChangedSchema,
  ProposedSceneAdvancedSchema,
  ProposedChapterEndedSchema,
  ProposedArcUpdatedSchema,
]);
export type ProposedUpdateEvent = z.infer<typeof ProposedUpdateEventSchema>;

export const ProposedUpdatesSchema = z
  .object({
    events: z.array(ProposedUpdateEventSchema).max(50).default([]),
  })
  .strict();
export type ProposedUpdates = z.infer<typeof ProposedUpdatesSchema>;

/**
 * Tool calls
 */
export const MemoryScopeSchema = z.enum([
  "character",
  "party",
  "world",
  "npc",
  "location",
  "any",
]);
export type MemoryScope = z.infer<typeof MemoryScopeSchema>;

export const ToolNameSchema = z.enum([
  "getCampaignContext",
  "getCharacterSheets",
  "retrieveMemory",
  "rollDice",
  "proposeUpdates",
  "createArc",
  "closeArc",
  "generateMediaPrompt",
]);
export type ToolName = z.infer<typeof ToolNameSchema>;

export const ToolCallSchema = z.discriminatedUnion("name", [
  z
    .object({
      name: z.literal("getCampaignContext"),
      arguments: z
        .object({
          campaign_id: IdString,
          party_id: IdString,
        })
        .strict(),
    })
    .strict(),

  z
    .object({
      name: z.literal("getCharacterSheets"),
      arguments: z
        .object({
          party_id: IdString,
        })
        .strict(),
    })
    .strict(),

  z
    .object({
      name: z.literal("retrieveMemory"),
      arguments: z
        .object({
          campaign_id: IdString,
          query: z.string().min(1).max(300),
          scope: MemoryScopeSchema.default("any"),
          k: z.number().int().min(1).max(12).default(6),
        })
        .strict(),
    })
    .strict(),

  z
    .object({
      name: z.literal("rollDice"),
      arguments: DiceRollSpecSchema,
    })
    .strict(),

  z
    .object({
      name: z.literal("proposeUpdates"),
      arguments: ProposedUpdatesSchema,
    })
    .strict(),

  z
    .object({
      name: z.literal("createArc"),
      arguments: z
        .object({
          campaign_id: IdString,
          party_id: IdString,
          title: z.string().min(1).max(120),
          goals: z.array(z.string().min(1).max(160)).max(12),
        })
        .strict(),
    })
    .strict(),

  z
    .object({
      name: z.literal("closeArc"),
      arguments: z
        .object({
          arc_id: IdString,
          outcome_summary: z.string().min(1).max(800),
        })
        .strict(),
    })
    .strict(),

  z
    .object({
      name: z.literal("generateMediaPrompt"),
      arguments: z
        .object({
          scene_context: z.string().min(1).max(1200),
          style_pack: StylePackSchema,
          sliders: StyleSlidersSchema,
        })
        .strict(),
    })
    .strict(),
]);
export type ToolCall = z.infer<typeof ToolCallSchema>;

/**
 * GM Response contract (JSON-only)
 */
export const GMResponseSchema = z
  .object({
    response_phase: ResponsePhaseSchema.default("final"),

    narrative_markdown: z.string().min(1).max(6000),

    // If ambiguous / conflicting intents, ask questions here; otherwise []
    clarifications: z.array(z.string().min(1).max(200)).max(8).default([]),

    // Must frame the scene every turn to maintain continuity
    scene: SceneSchema,

    // Tool calls requested this turn (can be [])
    tool_calls: z.array(ToolCallSchema).max(12).default([]),

    // Proposed state changes (MUST be validated server-side)
    proposed_updates: ProposedUpdatesSchema,

    // Optional UI hints (quick actions, pacing mode)
    ui_suggestions: UiSuggestionsSchema.optional(),

    // Ambience prompts (prompt builder; actual generation is separate)
    media_prompts: MediaPromptsSchema,

    // Optional narrative arc progress hint (not authoritative)
    chapter_progress: z
      .object({
        arc_id: IdString.optional(),
        beat: z
          .enum(["hook", "rise", "twist", "climax", "resolution", "reward"])
          .optional(),
        percent: Float01.optional(),
      })
      .strict()
      .optional(),
  })
  .strict();

export type GMResponse = z.infer<typeof GMResponseSchema>;
