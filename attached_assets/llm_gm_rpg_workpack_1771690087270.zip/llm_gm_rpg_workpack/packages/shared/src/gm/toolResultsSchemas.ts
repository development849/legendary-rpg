import { z } from "zod";
import {
  IdString,
  ToolNameSchema,
  DiceRollSpecSchema,
  ProposedUpdateEventSchema,
  MediaPromptsSchema,
  SceneSchema,
  StylePackSchema,
  StyleSlidersSchema,
  InventoryItemSchema,
  UiModeSchema,
} from "./schemas";

/**
 * Campaign settings returned by getCampaignContext
 */
export const CampaignRatingSchema = z.enum(["pg13", "mature"]);
export type CampaignRating = z.infer<typeof CampaignRatingSchema>;

export const CampaignContentTogglesSchema = z
  .object({
    no_romance: z.boolean().default(false),
    no_horror: z.boolean().default(false),
    fade_to_black: z.boolean().default(true),
  })
  .strict();

export const CampaignSettingsSchema = z
  .object({
    rating: CampaignRatingSchema.default("pg13"),
    content_toggles: CampaignContentTogglesSchema,
    ui_mode: UiModeSchema.default("balanced"),
    style_pack: StylePackSchema,
    sliders: StyleSlidersSchema,
  })
  .strict();

export type CampaignSettings = z.infer<typeof CampaignSettingsSchema>;

/**
 * Character summary returned by getCharacterSheets
 */
export const ClassIdSchema = z.enum(["fighter", "rogue", "wizard", "cleric"]);
export const ConditionIdSchema = z.enum(["poisoned", "stunned", "burning"]);

export const AbilityIdSchema = z.enum([
  "might",
  "agility",
  "endurance",
  "intellect",
  "will",
  "presence",
]);

export const SkillIdSchema = z.enum([
  "athletics",
  "acrobatics",
  "stealth",
  "thievery",
  "survival",
  "medicine",
  "lore",
  "investigation",
  "insight",
  "persuasion",
  "deception",
  "intimidation",
]);

export const CharacterSheetSummarySchema = z
  .object({
    character_id: IdString,
    name: z.string().min(1).max(80),
    class_id: ClassIdSchema,
    race: z.string().min(1).max(60).optional(),
    background_tags: z.array(z.string().min(1).max(40)).max(12).default([]),

    level: z.number().int().min(1).max(30),
    xp: z.number().int().min(0).max(1_000_000),

    hp_current: z.number().int().min(0).max(999),
    hp_max: z.number().int().min(1).max(999),

    abilities: z.record(AbilityIdSchema, z.number().int().min(1).max(30)),
    proficient_skills: z.array(SkillIdSchema).max(24).default([]),
    conditions: z.array(ConditionIdSchema).max(12).default([]),

    resources: z
      .object({
        focus_current: z.number().int().min(0).max(999).optional(),
        focus_max: z.number().int().min(0).max(999).optional(),
      })
      .strict()
      .default({}),

    inventory: z.array(InventoryItemSchema).max(200).default([]),
  })
  .strict();

export type CharacterSheetSummary = z.infer<typeof CharacterSheetSummarySchema>;

/**
 * Memory retrieval results
 */
export const MemoryScopeSchema = z.enum([
  "character",
  "party",
  "world",
  "npc",
  "location",
  "any",
]);

export const MemoryHitSchema = z
  .object({
    id: IdString,
    scope: MemoryScopeSchema,
    text: z.string().min(1).max(2000),
    score: z.number().finite().min(0).max(1),
    metadata: z.record(z.string(), z.any()).default({}),
  })
  .strict();

/**
 * Roll Dice Result
 */
export const RollDiceResultSchema = z
  .object({
    roll_id: IdString,
    spec: DiceRollSpecSchema,
    rolls: z.array(z.number().int().min(1).max(10_000)).min(1).max(20),
    kept_roll: z.number().int().min(1).max(10_000),
    total: z.number().int().min(-10_000).max(10_000),
    breakdown: z.string().min(1).max(400),
    timestamp_iso: z.string().min(10).max(40),
  })
  .strict();

/**
 * proposeUpdates result schema
 */
export const UpdateRejectionCodeSchema = z.enum([
  "UNKNOWN_EVENT",
  "INVALID_CHARACTER",
  "INVALID_NPC",
  "INVALID_QUEST",
  "INVALID_ARC",
  "NOT_IN_PARTY",
  "HP_OUT_OF_BOUNDS",
  "XP_INVALID",
  "LEVEL_UP_INVALID",
  "INSUFFICIENT_ITEM_QTY",
  "ITEM_NOT_FOUND",
  "DUPLICATE_OR_CONFLICTING",
  "CONSTRAINT_VIOLATION",
  "VALIDATION_FAILED",
]);

export const UpdateRejectionSchema = z
  .object({
    index: z.number().int().min(0),
    event_type: z.string().min(1).max(40),
    code: UpdateRejectionCodeSchema,
    message: z.string().min(1).max(400),
    path: z.array(z.union([z.string(), z.number()])).optional(),
  })
  .strict();

export const ProposeUpdatesResultSchema = z
  .object({
    atomic: z.boolean().default(true),
    accepted: z
      .array(
        z
          .object({
            index: z.number().int().min(0),
            normalized_event: ProposedUpdateEventSchema,
          })
          .strict()
      )
      .default([]),
    rejected: z.array(UpdateRejectionSchema).default([]),
    applied: z.boolean(),
    game_event_ids: z.array(IdString).default([]),
    new_world_state_version: z.number().int().min(0).optional(),
  })
  .strict();

/**
 * Generic tool error schema
 */
export const ToolErrorSchema = z
  .object({
    code: z.string().min(1).max(80),
    message: z.string().min(1).max(800),
    details: z.record(z.string(), z.any()).optional(),
  })
  .strict();

/**
 * Tool result envelopes
 */
const ToolOk = <T extends z.ZodTypeAny>(name: z.ZodLiteral<any>, result: T) =>
  z
    .object({
      name,
      ok: z.literal(true),
      result,
    })
    .strict();

const ToolFail = (name: z.ZodLiteral<any>) =>
  z
    .object({
      name,
      ok: z.literal(false),
      error: ToolErrorSchema,
    })
    .strict();

/**
 * Tool-specific result schemas
 */
export const GetCampaignContextResultSchema = z
  .object({
    campaign: z
      .object({
        campaign_id: IdString,
        title: z.string().min(1).max(120),
        settings: CampaignSettingsSchema,
      })
      .strict(),
    party: z
      .object({
        party_id: IdString,
        name: z.string().min(1).max(80),
      })
      .strict(),
    snapshot: z
      .object({
        scene: SceneSchema,
        world_state_version: z.number().int().min(0),
        updated_at_iso: z.string().min(10).max(40),
      })
      .strict(),
  })
  .strict();

export const GetCharacterSheetsResultSchema = z
  .object({
    party_id: IdString,
    characters: z.array(CharacterSheetSummarySchema).min(1).max(12),
  })
  .strict();

export const RetrieveMemoryResultSchema = z
  .object({
    campaign_id: IdString,
    scope: MemoryScopeSchema,
    hits: z.array(MemoryHitSchema).max(12).default([]),
  })
  .strict();

export const GenerateMediaPromptResultSchema = MediaPromptsSchema;

export const CreateArcResultSchema = z
  .object({
    arc_id: IdString,
    title: z.string().min(1).max(120),
    goals: z.array(z.string().min(1).max(160)).max(12),
    status: z.enum(["planned", "active", "completed", "abandoned"]),
  })
  .strict();

export const CloseArcResultSchema = z
  .object({
    arc_id: IdString,
    status: z.literal("completed"),
    outcome_summary: z.string().min(1).max(800),
  })
  .strict();

/**
 * Union of all tool results
 */
export const ToolResultSchema = z.union([
  ToolOk(z.literal("getCampaignContext"), GetCampaignContextResultSchema),
  ToolFail(z.literal("getCampaignContext")),

  ToolOk(z.literal("getCharacterSheets"), GetCharacterSheetsResultSchema),
  ToolFail(z.literal("getCharacterSheets")),

  ToolOk(z.literal("retrieveMemory"), RetrieveMemoryResultSchema),
  ToolFail(z.literal("retrieveMemory")),

  ToolOk(z.literal("rollDice"), RollDiceResultSchema),
  ToolFail(z.literal("rollDice")),

  ToolOk(z.literal("proposeUpdates"), ProposeUpdatesResultSchema),
  ToolFail(z.literal("proposeUpdates")),

  ToolOk(z.literal("generateMediaPrompt"), GenerateMediaPromptResultSchema),
  ToolFail(z.literal("generateMediaPrompt")),

  ToolOk(z.literal("createArc"), CreateArcResultSchema),
  ToolFail(z.literal("createArc")),

  ToolOk(z.literal("closeArc"), CloseArcResultSchema),
  ToolFail(z.literal("closeArc")),
]);

export type ToolResult = z.infer<typeof ToolResultSchema>;

export const ToolResultsMessageSchema = z
  .object({
    tool_results: z.array(ToolResultSchema).max(24),
  })
  .strict();

export type ToolResultsMessage = z.infer<typeof ToolResultsMessageSchema>;
