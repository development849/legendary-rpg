# Replit Agent Constraints Block (Prepend to Every Agent Request)

Always follow these constraints:

- LLM never mutates DB directly; it only proposes structured updates; server validates and commits.
- All dice and rules are server-side and logged as events.
- Event sourcing is mandatory: every action/outcome is a `game_event`.
- Use one external port: Fastify hosts Next SSR + APIs + WebSockets.
- Implement Replit Auth via Agent (official method).
- Use Replit SQL Database (Postgres) and migrations; keep prod safety in mind.
- No living-artist style imitation; only generic original style packs + sliders.
- Mobile-first responsive UI + PWA.
- Build milestone-by-milestone; keep a working app at all times.

Implementation anchors:
- Validate GM output JSON with `GMResponseSchema`.
- Use tool-result envelopes validated by `ToolResultsMessageSchema` before feeding tool results back to the model.
- Validate proposed updates with `validateProposedUpdates` (atomic by default).
